// $('.toggle').click(function(e){
//     e.preventDefault(); // The flicker is a codepen thing
//     $(this).toggleClass('toggle-on');
//     if(this) {
//         trans()
//         document.documentElement.setAttribute('data-theme', 'dark')
//       } else {
//         trans()
//           document.documentElement.setAttribute('data-theme', 'light')
//         }
//   });
//   let trans = () => {
//       document.documentElement.classList.add('transation');
//       window.setTimeout(() => {
//         document.documentElement.classList.remove('transation');
//       }, 1000)
//     }
// var slider = document.getElementById("myRange");
// // var output = document.getElementById("demo");
// // output.innerHTML = slider.value;

// slider.oninput = function() {
// //   output.innerHTML = this.value;
//   console.log(this.value);
// }