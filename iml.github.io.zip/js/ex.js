function ex() {
    return [
        //{ "type" : 1, "exam" : "", "ans" : "", "t_ans" : "" },
        //{ "type" : 2, "exam" : "", "ans" : "", "t_ans" : "" },
        //{ "type" : 5, "exam" : "", "t_ans" : "" },
       // { "type": 5, "exam": "面向对象的系统分析要确立的三个系统模型是__、__和__。", "t_ans": "对象,功能,动态" },
       // { "type": 5, "exam": "Although it was difficult at first, I soon grew __to running every morning.", "t_ans": "accustom" },
        // { 
        //     "type": 1, 
        //     "exam": "Although it was difficult at first, I soon grew ____to running every morning.", 
        //     "ans": "conscience|sensitive|accustom|relieve|consume|purchase|explosive|identify", 
        //     "t_ans": "accustom" 
        // },
        // { 
        //     "type": 1, 
        //     "exam": "My father ____ a new toaster at the store.", 
        //     "ans": "conscience|sensitive|accustom|relieve|consume|purchase|explosive|identify", 
        //     "t_ans": "purchase" 
        // },
        // { 
        //     "type": 1, 
        //     "exam": "Because I had not studied for the test, I was ____  when my teacher said he moved it  to next week.", 
        //     "ans": "conscience|sensitive|accustom|relieve|consume|purchase|explosive|identify", 
        //     "t_ans": "relieve" 
        // },
        // { 
        //     "type": 1, 
        //     "exam": "Although she looked familiar,I could not ____ her.", 
        //     "ans": "conscience|sensitive|accustom|relieve|consume|purchase|explosive|identify", 
        //     "t_ans": "identify" 
        // },
        // { 
        //     "type": 1, 
        //     "exam": "1. Mike was so hungry that he ____ the entirebag of chips.", 
        //     "ans": "conscience|sensitive|accustom|relieve|consume|purchase|explosive|identify", 
        //     "t_ans": "consume" 
        // },
        // { 
        //     "type": 1, 
        //     "exam": "I get sunburned easily, because my skin is so ____ .", 
        //     "ans": "conscience|sensitive|accustom|relieve|consume|purchase|explosive|identify", 
        //     "t_ans": "sensitive" 
        // },
        // { 
        //     "type": 1, 
        //     "exam": "My brother has a(n) ____ temper, and is quick to get very angry.", 
        //     "ans": "conscience|sensitive|accustom|relieve|consume|purchase|explosive|identify", 
        //     "t_ans": "explosive" 
        // },
        // { 
        //     "type": 1, 
        //     "exam": "The thief had a guilty ____ because he returned the wallet with nothing missing from it.", 
        //     "ans": "conscience|sensitive|accustom|relieve|consume|purchase|explosive|identify", 
        //     "t_ans": "conscience" 
        // },
        //综合教程的
        { "type": 5, "exam": "like most childern:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "N,O,K,F,A,I,M,L,C,B" },
        { "type": 5, "exam": "The elephant:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "C,L,O,K,H,E,M,F,B,I" },
        // { "type": 5, "exam": "when an:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "G,N,B,L,D,K,C,M,O,E" },
        // { "type": 5, "exam": "one day:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "B,C,E,H,D,K,M,O,A,I" },
        // { "type": 5, "exam": "Chinese-American:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "E,O,J,A,F,K,M,C,H,L" },
        // { "type": 5, "exam": "Before planting:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "O,N,A,E,G,C,I,K,O,H" },

        // //长篇阅读的
        // { "type": 5, "exam": "like most childern:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "N,O,K,F,A,I,M,L,C,B" },
        // { "type": 5, "exam": "The elephant:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "C,L,O,K,H,E,M,F,B,T" },
        // { "type": 5, "exam": "when an:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "G,N,B,L,D,K,C,M,O,E" },
        // { "type": 5, "exam": "one day:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "B,C,E,H,D,K,M,O,A,I" },
        // { "type": 5, "exam": "Chinese-American:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "E,O,J,A,F,K,M,C,H,L" },
        // { "type": 5, "exam": "Before planting:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "O,N,A,E,G,C,I,K,O,H" },
        // { "type": 5, "exam": "The elephant:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "C,L,O,K,H,E,M,F,B,T" },
        // { "type": 5, "exam": "when an:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "G,N,B,L,D,K,C,M,O,E" },
        // { "type": 5, "exam": "one day:__、__、__、__、__、__、__、__、__、__ ", "t_ans": "B,C,E,H,D,K,M,O,A,I" },

    ] 
}